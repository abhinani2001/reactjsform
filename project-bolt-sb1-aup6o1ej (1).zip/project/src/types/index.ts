export interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isLoading?: boolean;
  workItemForm?: WorkItemFormData;
  requiresInput?: boolean;
  inputType?: 'workItemType' | 'title' | 'assignedTo' | 'iterationPath' | 'description' | 'priority' | 'severity';
}

export interface WorkItem {
  id: number;
  title: string;
  workItemType: string;
  state: string;
  assignedTo?: string;
  createdBy: string;
  createdDate: string;
  description?: string;
  acceptanceCriteria?: string;
  tags?: string;
  parentId?: number;
  children?: WorkItem[];
  iterationPath?: string;
  areaPath?: string;
  priority?: number;
  severity?: string;
}

export interface WorkItemFormData {
  workItemType?: string;
  title?: string;
  description?: string;
  assignedTo?: string;
  iterationPath?: string;
  areaPath?: string;
  priority?: number;
  severity?: string;
  parentId?: number;
  tags?: string;
  acceptanceCriteria?: string;
}

export interface DevOpsQuery {
  wiql?: string;
  restApiUrl?: string;
  description: string;
  operation?: 'read' | 'create' | 'update';
  workItemData?: WorkItemFormData;
  workItemId?: number;
}

export interface AzureOpenAIRequest {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  max_tokens?: number;
  temperature?: number;
}

export interface AzureOpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export interface Config {
  azureOpenAI: {
    endpoint: string;
    apiKey: string;
    deploymentName: string;
    apiVersion: string;
  };
  azureDevOps: {
    organization: string;
    project: string;
  };
  azureAD: {
    clientId: string;
    tenantId: string;
    redirectUri: string;
  };
}

export interface UserProfile {
  displayName: string;
  mail: string;
  userPrincipalName: string;
}

export interface TeamMember {
  id: string;
  displayName: string;
  uniqueName: string;
}

export interface Iteration {
  id: string;
  name: string;
  path: string;
  startDate?: string;
  finishDate?: string;
}