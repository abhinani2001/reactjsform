import { Config } from '../types';

export const config: Config = {
  azureOpenAI: {
    endpoint: import.meta.env.VITE_AZURE_OPENAI_ENDPOINT || '',
    apiKey: import.meta.env.VITE_AZURE_OPENAI_KEY || '',
    deploymentName: import.meta.env.VITE_AZURE_DEPLOYMENT_NAME || 'gpt-4',
    apiVersion: import.meta.env.VITE_AZURE_API_VERSION || '2024-02-15-preview',
  },
  azureDevOps: {
    organization: import.meta.env.VITE_AZURE_DEVOPS_ORG || '',
    project: import.meta.env.VITE_AZURE_DEVOPS_PROJECT || '',
  },
  azureAD: {
    clientId: import.meta.env.VITE_AZURE_CLIENT_ID || '',
    tenantId: import.meta.env.VITE_AZURE_TENANT_ID || '',
    redirectUri: import.meta.env.VITE_AZURE_REDIRECT_URI || 'http://localhost:5173',
  },
};

export const validateConfig = (): boolean => {
  const requiredFields = [
    config.azureOpenAI.endpoint,
    config.azureOpenAI.apiKey,
    config.azureDevOps.organization,
    config.azureDevOps.project,
    config.azureAD.clientId,
    config.azureAD.tenantId,
  ];

  return requiredFields.every(field => field.trim() !== '');
};