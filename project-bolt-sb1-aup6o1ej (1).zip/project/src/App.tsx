import React, { useState, useCallback, useEffect } from 'react';
import { MsalProvider, AuthenticatedTemplate, UnauthenticatedTemplate, useMsal } from '@azure/msal-react';
import { PublicClientApplication } from '@azure/msal-browser';
import { Settings, Zap, Shield, Database, LogOut, User } from 'lucide-react';
import { ChatInterface } from './components/ChatInterface';
import { ConfigurationPanel } from './components/ConfigurationPanel';
import { LoginPage } from './components/LoginPage';
import { Message, WorkItemFormData, UserProfile } from './types';
import { azureOpenAIService } from './services/AzureOpenAIService';
import { azureDevOpsService } from './services/AzureDevOpsService';
import { validateConfig } from './config';
import { msalConfig, loginRequest } from './config/msalConfig';

const msalInstance = new PublicClientApplication(msalConfig);

const AppContent: React.FC = () => {
  const { instance, accounts } = useMsal();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [conversationContext, setConversationContext] = useState<string>('');
  const isConfigValid = validateConfig();

  useEffect(() => {
    if (accounts.length > 0) {
      const account = accounts[0];
      setUserProfile({
        displayName: account.name || '',
        mail: account.username || '',
        userPrincipalName: account.username || ''
      });

      // Get access token and set it for DevOps service
      instance.acquireTokenSilent({
        ...loginRequest,
        account: account,
      }).then((response) => {
        azureDevOpsService.setAccessToken(response.accessToken);
      }).catch((error) => {
        console.error('Token acquisition failed:', error);
      });
    }
  }, [accounts, instance]);

  const addMessage = useCallback((content: string, isUser: boolean, id?: string) => {
    const message: Message = {
      id: id || Date.now().toString(),
      content,
      isUser,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, message]);
    return message;
  }, []);

  const updateMessage = useCallback((id: string, content: string, isLoading = false) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id 
        ? { ...msg, content, isLoading }
        : msg
    ));
  }, []);

  const handleSendMessage = useCallback(async (userMessage: string) => {
    if (!isConfigValid) {
      setShowConfig(true);
      return;
    }

    // Add user message
    addMessage(userMessage, true);

    // Update conversation context
    const newContext = conversationContext + `\nUser: ${userMessage}`;
    setConversationContext(newContext);

    // Add loading bot message
    const botMessageId = `bot-${Date.now()}`;
    const botMessage = addMessage('', false, botMessageId);
    updateMessage(botMessageId, 'Processing your request...', true);
    setIsLoading(true);

    try {
      // Step 1: Interpret the query using Azure OpenAI
      updateMessage(botMessageId, 'Understanding your request...', true);
      const devOpsQuery = await azureOpenAIService.interpretQuery(userMessage, conversationContext);

      // Step 2: Execute the DevOps operation
      updateMessage(botMessageId, 
        devOpsQuery.operation === 'create' ? 'Creating work item...' :
        devOpsQuery.operation === 'update' ? 'Updating work item...' :
        'Querying Azure DevOps...', true);
      
      const devOpsResults = await azureDevOpsService.executeQuery(devOpsQuery);

      // Step 3: Summarize the results
      updateMessage(botMessageId, 'Analyzing results...', true);
      const summary = await azureOpenAIService.summarizeResults(devOpsResults, userMessage);

      // Step 4: Update with final response
      updateMessage(botMessageId, summary, false);

      // Update conversation context with bot response
      setConversationContext(newContext + `\nAssistant: ${summary}`);
    } catch (error) {
      console.error('Error processing message:', error);
      updateMessage(
        botMessageId,
        `I apologize, but I encountered an error while processing your request: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again or check your configuration.`,
        false
      );
    } finally {
      setIsLoading(false);
    }
  }, [isConfigValid, addMessage, updateMessage, conversationContext]);

  const handleCreateWorkItem = useCallback(async (workItemData: WorkItemFormData) => {
    if (!isConfigValid) {
      setShowConfig(true);
      return;
    }

    const botMessageId = `bot-${Date.now()}`;
    addMessage(`Creating ${workItemData.workItemType}: ${workItemData.title}`, true);
    const botMessage = addMessage('', false, botMessageId);
    updateMessage(botMessageId, 'Creating work item...', true);
    setIsLoading(true);

    try {
      const result = await azureDevOpsService.executeQuery({
        operation: 'create',
        workItemData,
        description: `Create ${workItemData.workItemType}`
      });

      const summary = await azureOpenAIService.summarizeResults(result, `Create ${workItemData.workItemType}`);
      updateMessage(botMessageId, summary, false);
    } catch (error) {
      console.error('Error creating work item:', error);
      updateMessage(
        botMessageId,
        `Failed to create work item: ${error instanceof Error ? error.message : 'Unknown error'}`,
        false
      );
    } finally {
      setIsLoading(false);
    }
  }, [isConfigValid, addMessage, updateMessage]);

  const handleUpdateWorkItem = useCallback(async (workItemId: number, workItemData: WorkItemFormData) => {
    if (!isConfigValid) {
      setShowConfig(true);
      return;
    }

    const botMessageId = `bot-${Date.now()}`;
    addMessage(`Updating work item ${workItemId}`, true);
    const botMessage = addMessage('', false, botMessageId);
    updateMessage(botMessageId, 'Updating work item...', true);
    setIsLoading(true);

    try {
      const result = await azureDevOpsService.executeQuery({
        operation: 'update',
        workItemId,
        workItemData,
        description: `Update work item ${workItemId}`
      });

      const summary = await azureOpenAIService.summarizeResults(result, `Update work item ${workItemId}`);
      updateMessage(botMessageId, summary, false);
    } catch (error) {
      console.error('Error updating work item:', error);
      updateMessage(
        botMessageId,
        `Failed to update work item: ${error instanceof Error ? error.message : 'Unknown error'}`,
        false
      );
    } finally {
      setIsLoading(false);
    }
  }, [isConfigValid, addMessage, updateMessage]);

  const handleLogout = () => {
    instance.logoutPopup();
  };

  return (
    <div className="h-screen flex flex-col bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <Database className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Azure DevOps AI Assistant</h1>
              <p className="text-sm text-gray-500">Intelligent insights for your development workflow</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {userProfile && (
              <div className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-100">
                <User className="h-4 w-4 text-gray-600" />
                <span className="text-sm text-gray-700">{userProfile.displayName}</span>
              </div>
            )}

            <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-gray-100">
              {isConfigValid ? (
                <>
                  <Shield className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-700">Connected</span>
                </>
              ) : (
                <>
                  <Shield className="h-4 w-4 text-red-500" />
                  <span className="text-sm text-red-700">Not Configured</span>
                </>
              )}
            </div>
            
            <button
              onClick={() => setShowConfig(true)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Configuration"
            >
              <Settings className="h-5 w-5" />
            </button>

            <button
              onClick={handleLogout}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Logout"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Feature highlights */}
        <div className="mt-4 flex items-center space-x-6 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <Zap className="h-4 w-4 text-blue-500" />
            <span>AI-Powered Operations</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-green-500" />
            <span>Full CRUD Support</span>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="h-4 w-4 text-purple-500" />
            <span>Secure Authentication</span>
          </div>
        </div>
      </header>

      {/* Chat Interface */}
      <main className="flex-1 min-h-0">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          onCreateWorkItem={handleCreateWorkItem}
          onUpdateWorkItem={handleUpdateWorkItem}
          isLoading={isLoading}
          disabled={!isConfigValid}
        />
      </main>

      {/* Configuration Panel */}
      <ConfigurationPanel
        isOpen={showConfig}
        onClose={() => setShowConfig(false)}
      />
    </div>
  );
};

function App() {
  return (
    <MsalProvider instance={msalInstance}>
      <AuthenticatedTemplate>
        <AppContent />
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <LoginPage />
      </UnauthenticatedTemplate>
    </MsalProvider>
  );
}

export default App;