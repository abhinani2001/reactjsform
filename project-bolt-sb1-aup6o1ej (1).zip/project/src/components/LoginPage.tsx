import React from 'react';
import { useMsal } from '@azure/msal-react';
import { loginRequest } from '../config/msalConfig';
import { Database, Shield, Zap, LogIn } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { instance } = useMsal();

  const handleLogin = () => {
    instance.loginPopup(loginRequest).catch(e => {
      console.error('Login failed:', e);
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Database className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Azure DevOps AI Assistant
            </h1>
            <p className="text-gray-600">
              Intelligent insights for your development workflow
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
              <Zap className="h-5 w-5 text-blue-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">AI-Powered Queries</p>
                <p className="text-sm text-gray-600">Natural language processing for DevOps data</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
              <Database className="h-5 w-5 text-green-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Full CRUD Operations</p>
                <p className="text-sm text-gray-600">Create, read, update work items seamlessly</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
              <Shield className="h-5 w-5 text-purple-500 flex-shrink-0" />
              <div>
                <p className="font-medium text-gray-900">Secure Authentication</p>
                <p className="text-sm text-gray-600">Microsoft Azure AD integration</p>
              </div>
            </div>
          </div>

          {/* Login Button */}
          <button
            onClick={handleLogin}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white py-3 px-4 rounded-xl font-medium hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-[1.02] flex items-center justify-center space-x-2"
          >
            <LogIn className="h-5 w-5" />
            <span>Sign in with Microsoft</span>
          </button>

          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              By signing in, you agree to access your Azure DevOps data
            </p>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Need help? Check your Azure AD configuration and ensure the app is registered with the correct permissions.
          </p>
        </div>
      </div>
    </div>
  );
};