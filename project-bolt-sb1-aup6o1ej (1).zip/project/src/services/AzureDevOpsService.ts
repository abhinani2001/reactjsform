import axios from 'axios';
import { config } from '../config';
import { WorkItem, DevOpsQuery, TeamMember, Iteration, WorkItemFormData } from '../types';

class AzureDevOpsService {
  private readonly baseURL: string;
  private accessToken: string = '';

  constructor() {
    this.baseURL = `https://dev.azure.com/${config.azureDevOps.organization}/${config.azureDevOps.project}/_apis`;
  }

  setAccessToken(token: string) {
    this.accessToken = token;
  }

  private get headers(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.accessToken}`,
    };
  }

  async executeQuery(query: DevOpsQuery): Promise<any> {
    try {
      switch (query.operation) {
        case 'create':
          return await this.createWorkItem(query.workItemData!);
        case 'update':
          return await this.updateWorkItem(query.workItemId!, query.workItemData!);
        case 'read':
        default:
          if (query.wiql) {
            return await this.executeWIQLQuery(query.wiql);
          } else if (query.restApiUrl) {
            return await this.executeRestApiCall(query.restApiUrl);
          } else {
            throw new Error('No valid query provided');
          }
      }
    } catch (error) {
      console.error('Error executing DevOps query:', error);
      throw new Error(`Failed to execute DevOps operation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async executeWIQLQuery(wiql: string): Promise<any> {
    const wiqlRequest = {
      query: wiql
    };

    const wiqlResponse = await axios.post(
      `${this.baseURL}/wit/wiql?api-version=7.0`,
      wiqlRequest,
      { headers: this.headers }
    );

    const workItemIds = wiqlResponse.data.workItems?.map((item: any) => item.id) || [];
    
    if (workItemIds.length === 0) {
      return { workItems: [], count: 0 };
    }

    const workItemsResponse = await axios.get(
      `${this.baseURL}/wit/workitems?ids=${workItemIds.join(',')}&$expand=all&api-version=7.0`,
      { headers: this.headers }
    );

    return {
      workItems: workItemsResponse.data.value,
      count: workItemIds.length,
      query: wiql
    };
  }

  private async executeRestApiCall(url: string): Promise<any> {
    const apiUrl = url.includes('dev.azure.com') ? url : `${this.baseURL}${url}`;
    const response = await axios.get(apiUrl, { headers: this.headers });
    return response.data;
  }

  async createWorkItem(workItemData: WorkItemFormData): Promise<any> {
    const patchDocument = this.buildPatchDocument(workItemData);
    
    const response = await axios.post(
      `${this.baseURL}/wit/workitems/$${workItemData.workItemType}?api-version=7.0`,
      patchDocument,
      { 
        headers: {
          ...this.headers,
          'Content-Type': 'application/json-patch+json'
        }
      }
    );

    return {
      success: true,
      workItem: this.mapWorkItem(response.data),
      message: `Successfully created ${workItemData.workItemType} with ID ${response.data.id}`
    };
  }

  async updateWorkItem(workItemId: number, workItemData: WorkItemFormData): Promise<any> {
    const patchDocument = this.buildPatchDocument(workItemData);
    
    const response = await axios.patch(
      `${this.baseURL}/wit/workitems/${workItemId}?api-version=7.0`,
      patchDocument,
      { 
        headers: {
          ...this.headers,
          'Content-Type': 'application/json-patch+json'
        }
      }
    );

    return {
      success: true,
      workItem: this.mapWorkItem(response.data),
      message: `Successfully updated work item ${workItemId}`
    };
  }

  private buildPatchDocument(workItemData: WorkItemFormData): any[] {
    const patchDocument: any[] = [];

    if (workItemData.title) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.Title',
        value: workItemData.title
      });
    }

    if (workItemData.description) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.Description',
        value: workItemData.description
      });
    }

    if (workItemData.assignedTo) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.AssignedTo',
        value: workItemData.assignedTo
      });
    }

    if (workItemData.iterationPath) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.IterationPath',
        value: workItemData.iterationPath
      });
    }

    if (workItemData.areaPath) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.AreaPath',
        value: workItemData.areaPath
      });
    }

    if (workItemData.priority) {
      patchDocument.push({
        op: 'add',
        path: '/fields/Microsoft.VSTS.Common.Priority',
        value: workItemData.priority
      });
    }

    if (workItemData.severity) {
      patchDocument.push({
        op: 'add',
        path: '/fields/Microsoft.VSTS.Common.Severity',
        value: workItemData.severity
      });
    }

    if (workItemData.acceptanceCriteria) {
      patchDocument.push({
        op: 'add',
        path: '/fields/Microsoft.VSTS.Common.AcceptanceCriteria',
        value: workItemData.acceptanceCriteria
      });
    }

    if (workItemData.tags) {
      patchDocument.push({
        op: 'add',
        path: '/fields/System.Tags',
        value: workItemData.tags
      });
    }

    if (workItemData.parentId) {
      patchDocument.push({
        op: 'add',
        path: '/relations/-',
        value: {
          rel: 'System.LinkTypes.Hierarchy-Reverse',
          url: `https://dev.azure.com/${config.azureDevOps.organization}/_apis/wit/workItems/${workItemData.parentId}`
        }
      });
    }

    return patchDocument;
  }

  async getTeamMembers(): Promise<TeamMember[]> {
    try {
      const response = await axios.get(
        `https://dev.azure.com/${config.azureDevOps.organization}/_apis/projects/${config.azureDevOps.project}/teams?api-version=7.0`,
        { headers: this.headers }
      );

      const defaultTeam = response.data.value[0];
      if (!defaultTeam) return [];

      const membersResponse = await axios.get(
        `https://dev.azure.com/${config.azureDevOps.organization}/_apis/projects/${config.azureDevOps.project}/teams/${defaultTeam.id}/members?api-version=7.0`,
        { headers: this.headers }
      );

      return membersResponse.data.value.map((member: any) => ({
        id: member.identity.id,
        displayName: member.identity.displayName,
        uniqueName: member.identity.uniqueName
      }));
    } catch (error) {
      console.error('Error fetching team members:', error);
      return [];
    }
  }

  async getIterations(): Promise<Iteration[]> {
    try {
      const response = await axios.get(
        `https://dev.azure.com/${config.azureDevOps.organization}/${config.azureDevOps.project}/_apis/work/teamsettings/iterations?api-version=7.0`,
        { headers: this.headers }
      );

      return response.data.value.map((iteration: any) => ({
        id: iteration.id,
        name: iteration.name,
        path: iteration.path,
        startDate: iteration.attributes?.startDate,
        finishDate: iteration.attributes?.finishDate
      }));
    } catch (error) {
      console.error('Error fetching iterations:', error);
      return [];
    }
  }

  private mapWorkItem(item: any): WorkItem {
    return {
      id: item.id,
      title: item.fields['System.Title'] || '',
      workItemType: item.fields['System.WorkItemType'] || '',
      state: item.fields['System.State'] || '',
      assignedTo: item.fields['System.AssignedTo']?.displayName || '',
      createdBy: item.fields['System.CreatedBy']?.displayName || '',
      createdDate: item.fields['System.CreatedDate'] || '',
      description: item.fields['System.Description'] || '',
      acceptanceCriteria: item.fields['Microsoft.VSTS.Common.AcceptanceCriteria'] || '',
      tags: item.fields['System.Tags'] || '',
      parentId: item.fields['System.Parent'] || undefined,
      iterationPath: item.fields['System.IterationPath'] || '',
      areaPath: item.fields['System.AreaPath'] || '',
      priority: item.fields['Microsoft.VSTS.Common.Priority'] || undefined,
      severity: item.fields['Microsoft.VSTS.Common.Severity'] || '',
    };
  }
}

export const azureDevOpsService = new AzureDevOpsService();