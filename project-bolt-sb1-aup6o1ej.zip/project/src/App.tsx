import React, { useState, useCallback } from 'react';
import { Settings, Zap, Shield, Database } from 'lucide-react';
import { ChatInterface } from './components/ChatInterface';
import { ConfigurationPanel } from './components/ConfigurationPanel';
import { Message } from './types';
import { azureOpenAIService } from './services/AzureOpenAIService';
import { azureDevOpsService } from './services/AzureDevOpsService';
import { validateConfig } from './config';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const isConfigValid = validateConfig();

  const addMessage = useCallback((content: string, isUser: boolean, id?: string) => {
    const message: Message = {
      id: id || Date.now().toString(),
      content,
      isUser,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, message]);
    return message;
  }, []);

  const updateMessage = useCallback((id: string, content: string, isLoading = false) => {
    setMessages(prev => prev.map(msg => 
      msg.id === id 
        ? { ...msg, content, isLoading }
        : msg
    ));
  }, []);

  const handleSendMessage = useCallback(async (userMessage: string) => {
    if (!isConfigValid) {
      setShowConfig(true);
      return;
    }

    // Add user message
    addMessage(userMessage, true);

    // Add loading bot message
    const botMessageId = `bot-${Date.now()}`;
    const botMessage = addMessage('', false, botMessageId);
    updateMessage(botMessageId, 'Processing your request...', true);
    setIsLoading(true);

    try {
      // Step 1: Interpret the query using Azure OpenAI
      updateMessage(botMessageId, 'Understanding your question...', true);
      const devOpsQuery = await azureOpenAIService.interpretQuery(userMessage);

      // Step 2: Execute the DevOps query
      updateMessage(botMessageId, 'Querying Azure DevOps...', true);
      const devOpsResults = await azureDevOpsService.executeQuery(devOpsQuery);

      // Step 3: Summarize the results
      updateMessage(botMessageId, 'Analyzing results...', true);
      const summary = await azureOpenAIService.summarizeResults(devOpsResults, userMessage);

      // Step 4: Update with final response
      updateMessage(botMessageId, summary, false);
    } catch (error) {
      console.error('Error processing message:', error);
      updateMessage(
        botMessageId,
        `I apologize, but I encountered an error while processing your request: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again or check your configuration.`,
        false
      );
    } finally {
      setIsLoading(false);
    }
  }, [isConfigValid, addMessage, updateMessage]);

  return (
    <div className="h-screen flex flex-col bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <Database className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Azure DevOps AI Assistant</h1>
              <p className="text-sm text-gray-500">Intelligent insights for your development workflow</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-gray-100">
              {isConfigValid ? (
                <>
                  <Shield className="h-4 w-4 text-green-500" />
                  <span className="text-sm text-green-700">Connected</span>
                </>
              ) : (
                <>
                  <Shield className="h-4 w-4 text-red-500" />
                  <span className="text-sm text-red-700">Not Configured</span>
                </>
              )}
            </div>
            
            <button
              onClick={() => setShowConfig(true)}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              title="Configuration"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        {/* Feature highlights */}
        <div className="mt-4 flex items-center space-x-6 text-sm text-gray-600">
          <div className="flex items-center space-x-2">
            <Zap className="h-4 w-4 text-blue-500" />
            <span>AI-Powered Queries</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-green-500" />
            <span>Real-time DevOps Data</span>
          </div>
          <div className="flex items-center space-x-2">
            <Shield className="h-4 w-4 text-purple-500" />
            <span>Secure Integration</span>
          </div>
        </div>
      </header>

      {/* Chat Interface */}
      <main className="flex-1 min-h-0">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
          disabled={!isConfigValid}
        />
      </main>

      {/* Configuration Panel */}
      <ConfigurationPanel
        isOpen={showConfig}
        onClose={() => setShowConfig(false)}
      />
    </div>
  );
}

export default App;