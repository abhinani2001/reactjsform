import axios from 'axios';
import { config } from '../config';
import { WorkItem, DevOpsQuery } from '../types';

class AzureDevOpsService {
  private readonly baseURL: string;
  private readonly headers: Record<string, string>;

  constructor() {
    this.baseURL = `https://dev.azure.com/${config.azureDevOps.organization}/${config.azureDevOps.project}/_apis`;
    this.headers = {
      'Content-Type': 'application/json',
      'Authorization': `Basic ${btoa(`:${config.azureDevOps.pat}`)}`,
    };
  }

  async executeQuery(query: DevOpsQuery): Promise<any> {
    try {
      if (query.wiql) {
        return await this.executeWIQLQuery(query.wiql);
      } else if (query.restApiUrl) {
        return await this.executeRestApiCall(query.restApiUrl);
      } else {
        throw new Error('No valid query provided');
      }
    } catch (error) {
      console.error('Error executing DevOps query:', error);
      throw new Error('Failed to execute DevOps query');
    }
  }

  private async executeWIQLQuery(wiql: string): Promise<any> {
    const wiqlRequest = {
      query: wiql
    };

    // Execute WIQL query
    const wiqlResponse = await axios.post(
      `${this.baseURL}/wit/wiql?api-version=7.0`,
      wiqlRequest,
      { headers: this.headers }
    );

    const workItemIds = wiqlResponse.data.workItems?.map((item: any) => item.id) || [];
    
    if (workItemIds.length === 0) {
      return { workItems: [], count: 0 };
    }

    // Get detailed work item information
    const workItemsResponse = await axios.get(
      `${this.baseURL}/wit/workitems?ids=${workItemIds.join(',')}&$expand=all&api-version=7.0`,
      { headers: this.headers }
    );

    return {
      workItems: workItemsResponse.data.value,
      count: workItemIds.length,
      query: wiql
    };
  }

  private async executeRestApiCall(url: string): Promise<any> {
    // Ensure the URL is properly formatted for Azure DevOps
    const apiUrl = url.includes('dev.azure.com') ? url : `${this.baseURL}${url}`;
    
    const response = await axios.get(apiUrl, { headers: this.headers });
    return response.data;
  }

  async getWorkItemHierarchy(parentId: number): Promise<WorkItem[]> {
    try {
      const response = await axios.get(
        `${this.baseURL}/wit/workitems/${parentId}?$expand=relations&api-version=7.0`,
        { headers: this.headers }
      );

      const workItem = response.data;
      const children: WorkItem[] = [];

      if (workItem.relations) {
        const childRelations = workItem.relations.filter(
          (rel: any) => rel.rel === 'System.LinkTypes.Hierarchy-Forward'
        );

        for (const relation of childRelations) {
          const childId = relation.url.split('/').pop();
          const childResponse = await axios.get(
            `${this.baseURL}/wit/workitems/${childId}?$expand=all&api-version=7.0`,
            { headers: this.headers }
          );
          children.push(this.mapWorkItem(childResponse.data));
        }
      }

      return children;
    } catch (error) {
      console.error('Error getting work item hierarchy:', error);
      return [];
    }
  }

  private mapWorkItem(item: any): WorkItem {
    return {
      id: item.id,
      title: item.fields['System.Title'] || '',
      workItemType: item.fields['System.WorkItemType'] || '',
      state: item.fields['System.State'] || '',
      assignedTo: item.fields['System.AssignedTo']?.displayName || '',
      createdBy: item.fields['System.CreatedBy']?.displayName || '',
      createdDate: item.fields['System.CreatedDate'] || '',
      description: item.fields['System.Description'] || '',
      acceptanceCriteria: item.fields['Microsoft.VSTS.Common.AcceptanceCriteria'] || '',
      tags: item.fields['System.Tags'] || '',
      parentId: item.fields['System.Parent'] || undefined,
    };
  }
}

export const azureDevOpsService = new AzureDevOpsService();