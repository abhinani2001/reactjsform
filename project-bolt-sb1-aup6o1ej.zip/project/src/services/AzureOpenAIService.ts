import axios from 'axios';
import { config } from '../config';
import { AzureOpenAIRequest, AzureOpenAIResponse, DevOpsQuery } from '../types';

class AzureOpenAIService {
  private readonly baseURL: string;
  private readonly headers: Record<string, string>;

  constructor() {
    this.baseURL = `${config.azureOpenAI.endpoint}/openai/deployments/${config.azureOpenAI.deploymentName}/chat/completions?api-version=${config.azureOpenAI.apiVersion}`;
    this.headers = {
      'Content-Type': 'application/json',
      'api-key': config.azureOpenAI.apiKey,
    };
  }

  async interpretQuery(userQuery: string): Promise<DevOpsQuery> {
    const systemPrompt = `You are an Azure DevOps expert. Convert natural language queries into Azure DevOps REST API calls or WIQL queries.

For the query, provide:
1. A WIQL query if searching for work items
2. Or a REST API endpoint if getting specific data
3. A description of what the query does

Available work item types: Epic, Feature, User Story, Task, Bug, Issue
Available fields: System.Id, System.Title, System.WorkItemType, System.State, System.AssignedTo, System.CreatedBy, System.CreatedDate, System.Description, Microsoft.VSTS.Common.AcceptanceCriteria, System.Tags, System.Parent

Current organization: ${config.azureDevOps.organization}
Current project: ${config.azureDevOps.project}

Respond in JSON format:
{
  "wiql": "SELECT System.Id, System.Title FROM WorkItems WHERE...",
  "restApiUrl": "https://dev.azure.com/org/project/_apis/wit/workitems/123",
  "description": "Description of what this query does"
}

Only include wiql OR restApiUrl, not both.`;

    const request: AzureOpenAIRequest = {
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userQuery }
      ],
      max_tokens: 500,
      temperature: 0.1,
    };

    try {
      const response = await axios.post<AzureOpenAIResponse>(this.baseURL, request, { headers: this.headers });
      const content = response.data.choices[0]?.message?.content;
      
      if (!content) {
        throw new Error('No response from Azure OpenAI');
      }

      return JSON.parse(content);
    } catch (error) {
      console.error('Error interpreting query:', error);
      throw new Error('Failed to interpret your query. Please try rephrasing.');
    }
  }

  async summarizeResults(rawData: any, originalQuery: string): Promise<string> {
    const systemPrompt = `You are an Azure DevOps assistant. Summarize the DevOps data in a clear, natural language response.
    
Focus on:
- Work item counts and types
- Important details like assignees, states, dates
- Hierarchy relationships (Epic → Feature → User Story → Task/Bug)
- Key insights or patterns

Keep the response conversational and helpful.`;

    const userPrompt = `Original query: "${originalQuery}"

DevOps data to summarize:
${JSON.stringify(rawData, null, 2)}

Please provide a clear, helpful summary of this data.`;

    const request: AzureOpenAIRequest = {
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 800,
      temperature: 0.3,
    };

    try {
      const response = await axios.post<AzureOpenAIResponse>(this.baseURL, request, { headers: this.headers });
      const content = response.data.choices[0]?.message?.content;
      
      if (!content) {
        throw new Error('No response from Azure OpenAI');
      }

      return content;
    } catch (error) {
      console.error('Error summarizing results:', error);
      throw new Error('Failed to summarize the results.');
    }
  }
}

export const azureOpenAIService = new AzureOpenAIService();