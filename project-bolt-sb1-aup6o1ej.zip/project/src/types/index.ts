export interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  isLoading?: boolean;
}

export interface WorkItem {
  id: number;
  title: string;
  workItemType: string;
  state: string;
  assignedTo?: string;
  createdBy: string;
  createdDate: string;
  description?: string;
  acceptanceCriteria?: string;
  tags?: string;
  parentId?: number;
  children?: WorkItem[];
}

export interface DevOpsQuery {
  wiql?: string;
  restApiUrl?: string;
  description: string;
}

export interface AzureOpenAIRequest {
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  max_tokens?: number;
  temperature?: number;
}

export interface AzureOpenAIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export interface Config {
  azureOpenAI: {
    endpoint: string;
    apiKey: string;
    deploymentName: string;
    apiVersion: string;
  };
  azureDevOps: {
    organization: string;
    project: string;
    pat: string;
  };
}