import { Config } from '../types';

export const config: Config = {
  azureOpenAI: {
    endpoint: import.meta.env.VITE_AZURE_OPENAI_ENDPOINT || '',
    apiKey: import.meta.env.VITE_AZURE_OPENAI_KEY || '',
    deploymentName: import.meta.env.VITE_AZURE_DEPLOYMENT_NAME || 'gpt-4',
    apiVersion: import.meta.env.VITE_AZURE_API_VERSION || '2024-02-15-preview',
  },
  azureDevOps: {
    organization: import.meta.env.VITE_AZURE_DEVOPS_ORG || '',
    project: import.meta.env.VITE_AZURE_DEVOPS_PROJECT || '',
    pat: import.meta.env.VITE_AZURE_DEVOPS_PAT || '',
  },
};

export const validateConfig = (): boolean => {
  const requiredFields = [
    config.azureOpenAI.endpoint,
    config.azureOpenAI.apiKey,
    config.azureDevOps.organization,
    config.azureDevOps.project,
    config.azureDevOps.pat,
  ];

  return requiredFields.every(field => field.trim() !== '');
};