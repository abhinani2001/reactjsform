import React, { useState } from 'react';
import { Settings, Eye, EyeOff, CheckCircle, AlertCircle } from 'lucide-react';
import { config, validateConfig } from '../config';

interface ConfigurationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ConfigurationPanel: React.FC<ConfigurationPanelProps> = ({ isOpen, onClose }) => {
  const [showKeys, setShowKeys] = useState(false);
  const isConfigValid = validateConfig();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="h-6 w-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">Configuration</h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              ×
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-4">
              {isConfigValid ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-500" />
              )}
              <span className={`font-medium ${isConfigValid ? 'text-green-700' : 'text-red-700'}`}>
                Configuration Status: {isConfigValid ? 'Valid' : 'Invalid'}
              </span>
            </div>
            
            {!isConfigValid && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                <p className="text-red-700 text-sm">
                  Please create a <code className="bg-red-100 px-1 rounded">.env</code> file in your project root 
                  and configure the required environment variables. Check the <code className="bg-red-100 px-1 rounded">.env.example</code> file for reference.
                </p>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">Azure OpenAI Configuration</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Endpoint</label>
                  <input
                    type="text"
                    value={config.azureOpenAI.endpoint}
                    readOnly
                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    placeholder="https://your-resource.openai.azure.com/"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
                  <div className="relative">
                    <input
                      type={showKeys ? 'text' : 'password'}
                      value={config.azureOpenAI.apiKey}
                      readOnly
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md bg-gray-50 text-sm"
                      placeholder="Your API key"
                    />
                    <button
                      onClick={() => setShowKeys(!showKeys)}
                      className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600"
                    >
                      {showKeys ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Deployment Name</label>
                    <input
                      type="text"
                      value={config.azureOpenAI.deploymentName}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">API Version</label>
                    <input
                      type="text"
                      value={config.azureOpenAI.apiVersion}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-3">Azure DevOps Configuration</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Organization</label>
                    <input
                      type="text"
                      value={config.azureDevOps.organization}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Project</label>
                    <input
                      type="text"
                      value={config.azureDevOps.project}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Personal Access Token</label>
                  <div className="relative">
                    <input
                      type={showKeys ? 'text' : 'password'}
                      value={config.azureDevOps.pat}
                      readOnly
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md bg-gray-50 text-sm"
                      placeholder="Your PAT token"
                    />
                    <button
                      onClick={() => setShowKeys(!showKeys)}
                      className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600"
                    >
                      {showKeys ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-gray-200">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-2">Getting Started</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Copy <code className="bg-blue-100 px-1 rounded">.env.example</code> to <code className="bg-blue-100 px-1 rounded">.env</code></li>
                <li>• Fill in your Azure OpenAI and DevOps credentials</li>
                <li>• Restart the development server</li>
                <li>• Start chatting with your DevOps data!</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};