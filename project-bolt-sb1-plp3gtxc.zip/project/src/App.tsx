import React from 'react';
import { ChatContainer } from './components/ChatContainer';

function App() {
  return (
    <div className="w-full h-screen">
      <ChatContainer />
    </div>
  );
}

export default App;