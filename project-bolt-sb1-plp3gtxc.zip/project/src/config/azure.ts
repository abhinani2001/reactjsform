import { AzureOpenAIConfig } from '../types/chat';

export const azureConfig: AzureOpenAIConfig = {
  endpoint: import.meta.env.VITE_AZURE_OPENAI_ENDPOINT || '',
  apiKey: import.meta.env.VITE_AZURE_OPENAI_KEY || '',
  deploymentName: import.meta.env.VITE_AZURE_DEPLOYMENT_NAME || 'gpt-35-turbo',
  apiVersion: import.meta.env.VITE_AZURE_API_VERSION || '2024-04-01-preview',
};

export const isConfigured = () => {
  return azureConfig.endpoint && azureConfig.apiKey;
};