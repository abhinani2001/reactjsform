import axios from 'axios';
import { azureConfig } from '../config/azure';
import { ChatMessage, ChatResponse } from '../types/chat';

export class AzureOpenAIService {
  private baseURL: string;
  private headers: Record<string, string>;

  constructor() {
    this.baseURL = `${azureConfig.endpoint}/openai/deployments/${azureConfig.deploymentName}/chat/completions?api-version=${azureConfig.apiVersion}`;
    this.headers = {
      'Content-Type': 'application/json',
      'api-key': azureConfig.apiKey,
    };
  }

  async sendMessage(messages: ChatMessage[]): Promise<string> {
    try {
      const formattedMessages = messages
        .filter(msg => !msg.isLoading)
        .map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

      const response = await axios.post<ChatResponse>(
        this.baseURL,
        {
          messages: formattedMessages,
          max_tokens: 1000,
          temperature: 0.7,
          top_p: 0.9,
        },
        { headers: this.headers }
      );

      return response.data.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
    } catch (error) {
      console.error('Azure OpenAI API Error:', error);
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 401) {
          throw new Error('Invalid API key or unauthorized access');
        } else if (error.response?.status === 429) {
          throw new Error('Rate limit exceeded. Please try again later.');
        } else if (error.response?.status >= 500) {
          throw new Error('Azure OpenAI service is temporarily unavailable');
        }
      }
      throw new Error('Failed to get response from Azure OpenAI');
    }
  }
}

export const azureOpenAIService = new AzureOpenAIService();