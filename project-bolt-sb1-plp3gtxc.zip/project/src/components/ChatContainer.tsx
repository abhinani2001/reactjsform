import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from './ChatMessage';
import { ChatInput } from './ChatInput';
import { ConfigurationModal } from './ConfigurationModal';
import { ChatMessage as ChatMessageType } from '../types/chat';
import { azureOpenAIService } from '../services/azureOpenAI';
import { isConfigured } from '../config/azure';
import { Bot, Settings, Trash2, MessageSquare } from 'lucide-react';

export const ChatContainer: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(!isConfigured());
  const [error, setError] = useState<string>('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Add welcome message
    if (messages.length === 0 && isConfigured()) {
      setMessages([
        {
          id: '1',
          content: "Hello! I'm your AI assistant powered by Azure OpenAI. How can I help you today?",
          role: 'assistant',
          timestamp: new Date(),
        },
      ]);
    }
  }, [messages.length]);

  const handleSendMessage = async (content: string) => {
    if (!isConfigured()) {
      setShowConfig(true);
      return;
    }

    const userMessage: ChatMessageType = {
      id: Date.now().toString(),
      content,
      role: 'user',
      timestamp: new Date(),
    };

    const loadingMessage: ChatMessageType = {
      id: (Date.now() + 1).toString(),
      content: '',
      role: 'assistant',
      timestamp: new Date(),
      isLoading: true,
    };

    setMessages(prev => [...prev, userMessage, loadingMessage]);
    setIsLoading(true);
    setError('');

    try {
      const response = await azureOpenAIService.sendMessage([...messages, userMessage]);
      
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingMessage.id 
            ? { ...msg, content: response, isLoading: false }
            : msg
        )
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      setMessages(prev => prev.filter(msg => msg.id !== loadingMessage.id));
    } finally {
      setIsLoading(false);
    }
  };

  const handleConfigSave = (config: any) => {
    // In a real app, you'd save this to environment variables or secure storage
    // For demo purposes, we'll just update the window object
    (window as any).__AZURE_CONFIG__ = config;
    setShowConfig(false);
    
    // Add welcome message after configuration
    if (messages.length === 0) {
      setMessages([
        {
          id: '1',
          content: "Configuration saved! I'm now ready to assist you. How can I help you today?",
          role: 'assistant',
          timestamp: new Date(),
        },
      ]);
    }
  };

  const clearChat = () => {
    setMessages([]);
    setError('');
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Bot size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">Azure AI Assistant</h1>
              <p className="text-sm text-gray-500">Powered by Azure OpenAI</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowConfig(true)}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              title="Settings"
            >
              <Settings size={18} />
            </button>
            <button
              onClick={clearChat}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              title="Clear Chat"
              disabled={messages.length === 0}
            >
              <Trash2 size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 p-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <MessageSquare size={24} />
            </div>
            <h3 className="text-lg font-medium mb-2">Start a conversation</h3>
            <p className="text-center max-w-md">
              {isConfigured() 
                ? "Ask me anything! I'm here to help with information, analysis, coding, and more."
                : "Configure your Azure OpenAI credentials to get started."
              }
            </p>
          </div>
        ) : (
          <div className="space-y-0">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border-t border-red-200 px-4 py-3">
          <div className="text-red-800 text-sm">
            <strong>Error:</strong> {error}
          </div>
        </div>
      )}

      {/* Input */}
      <ChatInput
        onSendMessage={handleSendMessage}
        disabled={isLoading || !isConfigured()}
        placeholder={
          !isConfigured() 
            ? "Configure Azure OpenAI to start chatting..." 
            : "Type your message..."
        }
      />

      {/* Configuration Modal */}
      <ConfigurationModal
        isOpen={showConfig}
        onClose={() => setShowConfig(false)}
        onSave={handleConfigSave}
      />
    </div>
  );
};