import React, { useState } from 'react';
import { X, Settings, AlertTriangle } from 'lucide-react';

interface ConfigurationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (config: {
    endpoint: string;
    apiKey: string;
    deploymentName: string;
    apiVersion: string;
  }) => void;
}

export const ConfigurationModal: React.FC<ConfigurationModalProps> = ({
  isOpen,
  onClose,
  onSave,
}) => {
  const [config, setConfig] = useState({
    endpoint: '',
    apiKey: '',
    deploymentName: 'gpt-35-turbo',
    apiVersion: '2024-04-01-preview',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateConfig = () => {
    const newErrors: Record<string, string> = {};
    
    if (!config.endpoint) {
      newErrors.endpoint = 'Azure OpenAI endpoint is required';
    } else if (!config.endpoint.includes('openai.azure.com')) {
      newErrors.endpoint = 'Please enter a valid Azure OpenAI endpoint';
    }
    
    if (!config.apiKey) {
      newErrors.apiKey = 'API key is required';
    }
    
    if (!config.deploymentName) {
      newErrors.deploymentName = 'Deployment name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (validateConfig()) {
      onSave(config);
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-2">
            <Settings size={20} className="text-blue-500" />
            <h2 className="text-xl font-semibold">Azure OpenAI Configuration</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex gap-3">
            <AlertTriangle size={20} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800">
              <p className="font-medium mb-1">Configuration Required</p>
              <p>Please enter your Azure OpenAI credentials to start chatting. Your credentials will be stored locally in your browser.</p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Azure OpenAI Endpoint *
            </label>
            <input
              type="url"
              value={config.endpoint}
              onChange={(e) => setConfig({ ...config, endpoint: e.target.value })}
              placeholder="https://your-resource-name.openai.azure.com"
              className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.endpoint ? 'border-red-300' : 'border-gray-300'
              }`}
            />
            {errors.endpoint && (
              <p className="mt-1 text-sm text-red-600">{errors.endpoint}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              API Key *
            </label>
            <input
              type="password"
              value={config.apiKey}
              onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
              placeholder="Enter your Azure OpenAI API key"
              className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.apiKey ? 'border-red-300' : 'border-gray-300'
              }`}
            />
            {errors.apiKey && (
              <p className="mt-1 text-sm text-red-600">{errors.apiKey}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Deployment Name *
            </label>
            <input
              type="text"
              value={config.deploymentName}
              onChange={(e) => setConfig({ ...config, deploymentName: e.target.value })}
              placeholder="gpt-35-turbo"
              className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                errors.deploymentName ? 'border-red-300' : 'border-gray-300'
              }`}
            />
            {errors.deploymentName && (
              <p className="mt-1 text-sm text-red-600">{errors.deploymentName}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              API Version
            </label>
            <input
              type="text"
              value={config.apiVersion}
              onChange={(e) => setConfig({ ...config, apiVersion: e.target.value })}
              placeholder="2024-04-01-preview"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex gap-3 p-6 border-t">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Save Configuration
          </button>
        </div>
      </div>
    </div>
  );
};